package com.example.swiftly;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class DriverDashboardActivity extends AppCompatActivity implements OnMapReadyCallback {

    private static final int REQUEST_CODE = 100;
    private static final long MIN_TIME = 2000; // 2 seconds
    private static final long MIN_DIST = 0;   // 0 meters
    private GoogleMap mMap;
    private DatabaseReference databaseReference;
    private LocationManager locationManager;
    private LocationListener locationListener;
    private Button shareButton, stopSharingButton, logoutB, scannerB;

    // Flag to check if location sharing has started
    private boolean isLocationSharingStarted = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_dashboard);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        // Initialize Firebase Database
        String username = getIntent().getStringExtra("driverId");
        if (username == null || username.isEmpty()) {
            Toast.makeText(this, "Username is missing", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        databaseReference = FirebaseDatabase.getInstance().getReference("Location").child(username);

        // Initialize UI elements
        shareButton = findViewById(R.id.button);
        stopSharingButton = findViewById(R.id.stopSharingButton);
        logoutB = findViewById(R.id.logoutDriver);
        scannerB = findViewById(R.id.scannerButton);

        // Set button listeners
        shareButton.setOnClickListener(v -> shareCurrentLocation());
        stopSharingButton.setOnClickListener(v -> stopSharingLocation());
        logoutB.setOnClickListener(v -> logout());
        scannerB.setOnClickListener(v -> startActivity(new Intent(this, ScannerActivity.class)));

        // Request location permissions
        ActivityCompat.requestPermissions(this, new String[]{
                Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION
        }, REQUEST_CODE);

        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
    }

    private void shareCurrentLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_CODE);
            return;
        }

        try {
            locationListener = location -> {
                if (location != null) {
                    double latitude = location.getLatitude();
                    double longitude = location.getLongitude();

                    // Update Firebase
                    databaseReference.child("latitude").setValue(latitude);
                    databaseReference.child("longitude").setValue(longitude).addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            String locationMessage = "My current location:\nLatitude: " + latitude + "\nLongitude: " + longitude;
                            shareLocationMessage(locationMessage);
                        } else {
                            Toast.makeText(this, "Failed to update location in Firebase", Toast.LENGTH_SHORT).show();
                        }
                    });

                    // Update the map
                    LatLng latLng = new LatLng(latitude, longitude);
                    if (mMap != null) {
                        mMap.clear();
                        mMap.addMarker(new MarkerOptions().position(latLng).title("Location Updated"));
                        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15));
                    }

                    // Check if it's the first time sharing the location
                    if (!isLocationSharingStarted) {
                        isLocationSharingStarted = true;
                        Toast.makeText(this, "Location Shared Successfully", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(this, "Unable to fetch location", Toast.LENGTH_SHORT).show();
                }
            };

            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, MIN_TIME, MIN_DIST, locationListener);
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, MIN_TIME, MIN_DIST, locationListener);

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error fetching location", Toast.LENGTH_SHORT).show();
        }
    }

    private void shareLocationMessage(String locationMessage) {
        // The Toast message is now handled inside shareCurrentLocation method after location is shared
    }

    private void stopSharingLocation() {
        databaseReference.removeValue().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(this, "Location sharing stopped", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Failed to stop sharing", Toast.LENGTH_SHORT).show();
            }
        });

        // Remove location updates to save resources
        if (locationManager != null && locationListener != null) {
            locationManager.removeUpdates(locationListener);
        }

        // Reset the sharing flag when stopping the location sharing
        isLocationSharingStarted = false;
    }

    private void logout() {
        FirebaseAuth.getInstance().signOut();
        Intent intent = new Intent(this, DriverLoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
