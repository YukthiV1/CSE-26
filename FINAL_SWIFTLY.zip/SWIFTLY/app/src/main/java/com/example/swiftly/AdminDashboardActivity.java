package com.example.swiftly;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class AdminDashboardActivity extends AppCompatActivity {

    private EditText driverIdInput, driverPasswordInput;
    private Button createDriverButton, logout;
    private FirebaseFirestore firestore;
    private TextView crowDetails;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);

        firestore = FirebaseFirestore.getInstance();

        driverIdInput = findViewById(R.id.driver_id_input);
        driverPasswordInput = findViewById(R.id.driver_password_input);
        createDriverButton = findViewById(R.id.createDriver);
        crowDetails =  findViewById(R.id.crowd_mgmt);
        logout = findViewById(R.id.logout);
        crowDetails.setOnClickListener(v -> {
            Intent intent = new Intent(AdminDashboardActivity.this, CrowdManagement.class);
            startActivity(intent);
        });

        logout.setOnClickListener(v -> {
            logout();
        });
        createDriverButton.setOnClickListener(view -> {
            String driverId = driverIdInput.getText().toString().trim();
            String driverPassword = driverPasswordInput.getText().toString().trim();

            if (TextUtils.isEmpty(driverId)) {
                Toast.makeText(AdminDashboardActivity.this, "Please enter Driver ID", Toast.LENGTH_SHORT).show();
                return;
            }

            if (TextUtils.isEmpty(driverPassword)) {
                Toast.makeText(AdminDashboardActivity.this, "Please enter Password", Toast.LENGTH_SHORT).show();
                return;
            }

            saveDriverToFirestore(driverId, driverPassword);
        });
    }

    private void logout() {
        FirebaseAuth.getInstance().signOut();
        Intent intent = new Intent(AdminDashboardActivity.this, AdminActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK); // Clears activity stack
        startActivity(intent);
        finish();
    }

    private void saveDriverToFirestore(String driverId, String driverPassword) {
        Map<String, Object> driverDetails = new HashMap<>();
        driverDetails.put("driverId", driverId);
        driverDetails.put("password", driverPassword);

        firestore.collection("drivers")
                .document(driverId)
                .set(driverDetails)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(AdminDashboardActivity.this, "Driver credentials saved successfully", Toast.LENGTH_SHORT).show();
                        driverIdInput.setText("");
                        driverPasswordInput.setText("");
                    } else {
                        Toast.makeText(AdminDashboardActivity.this, "Failed to save credentials: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }
}