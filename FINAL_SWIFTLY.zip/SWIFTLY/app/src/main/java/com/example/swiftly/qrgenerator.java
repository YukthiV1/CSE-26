package com.example.swiftly;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.qrcode.QRCodeWriter;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class qrgenerator extends AppCompatActivity {
    private Spinner sourceSpinner, destinationSpinner;
    private EditText passengerCountInput, amountInput;
    private Button generateButton;
    private ImageView qrCodeImage;
    private FirebaseFirestore db;
    private Map<String, Integer> fareMap;
    //    private static final int UPI_PAYMENT = 123;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qrgenerator);

        // Initialize views
        sourceSpinner = findViewById(R.id.sourceSpinner);
        destinationSpinner = findViewById(R.id.destinationSpinner);
        passengerCountInput = findViewById(R.id.passengerCountInput);
        generateButton = findViewById(R.id.generateButton);
        qrCodeImage = findViewById(R.id.qrCodeImage);
        amountInput = findViewById(R.id.amountInput);

        // Initialize Firestore
        db = FirebaseFirestore.getInstance();

        // Initialize fare map
        initializeFareMap();

        // Set up Spinners with sample data
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.locations, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sourceSpinner.setAdapter(adapter);
        destinationSpinner.setAdapter(adapter);

        // Generate button click listener
        generateButton.setOnClickListener(v -> {
            // Disable the button to prevent multiple clicks
            generateButton.setEnabled(false);

            // Validate inputs before proceeding
            if (validateInputs()) {
                generateQRCode();
                // payUsingUpi();
            }

            // Re-enable the button after 5 seconds (or after QR code generation is done)
            generateButton.postDelayed(() -> generateButton.setEnabled(true), 5000);
        });

    }

    private void initializeFareMap() {
        fareMap = new HashMap<>();

        fareMap.put("Nagenahalli Gate - Singanayakanahalli", 1);
        fareMap.put("Singanayakanahalli - Honnenahalli", 15);
        fareMap.put("Honnenahalli - Rajanukunte", 20);
        fareMap.put("Rajanukunte - Presidency University", 25);

        fareMap.put("Nagenahalli Gate - Honnenahalli", 12);
        fareMap.put("Nagenahalli Gate - Rajanukunte", 18);
        fareMap.put("Nagenahalli Gate - Presidency University", 8);

        fareMap.put("Singanayakanahalli - Nagenahalli Gate", 10);
        fareMap.put("Singanayakanahalli - Rajanukunte", 7);
        fareMap.put("Singanayakanahalli - Presidency University", 16);

        fareMap.put("Honnenahalli - Nagenahalli Gate", 12);
        fareMap.put("Honnenahalli - Singanayakanahalli", 15);
        fareMap.put("Honnenahalli - Presidency University", 13);

        fareMap.put("Rajanukunte - Nagenahalli Gate", 18);
        fareMap.put("Rajanukunte - Singanayakanahalli", 7);
        fareMap.put("Rajanukunte - Honnenahalli", 20);
        fareMap.put("Rajanukunte - Presidency University", 25);

        fareMap.put("Presidency University - Nagenahalli Gate", 8);
        fareMap.put("Presidency University - Singanayakanahalli", 16);
        fareMap.put("Presidency University - Honnenahalli", 13);
        fareMap.put("Presidency University - Rajanukunte", 25);
    }

    private boolean validateInputs() {
        String passengerCountStr = passengerCountInput.getText().toString().trim();
        try {
            int passengerCount = Integer.parseInt(passengerCountStr);
            if (passengerCount <= 0) {
                Toast.makeText(this, "Enter a valid passenger count", Toast.LENGTH_SHORT).show();
                return false;
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Passenger count must be a number", Toast.LENGTH_SHORT).show();
            return false;
        }

        String source = sourceSpinner.getSelectedItem().toString();
        String destination = destinationSpinner.getSelectedItem().toString();
        if (source.equals(destination)) {
            Toast.makeText(this, "Source and destination cannot be the same", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }

    private void generateQRCode() {
        String source = sourceSpinner.getSelectedItem().toString();
        String destination = destinationSpinner.getSelectedItem().toString();
        String passengerCountStr = passengerCountInput.getText().toString().trim();

        int passengerCount = Integer.parseInt(passengerCountStr);
        String route = source + " - " + destination;
        Integer fare = fareMap.get(route);
        int totalAmount = fare * passengerCount;
        runOnUiThread(() -> {
            // Dynamically update the EditText with the total amount
            amountInput.setText(String.valueOf(totalAmount));
        });

        String transactionId = UUID.randomUUID().toString();

        QRCodeWriter writer = new QRCodeWriter();
        String ticketData = "Source: " + source + "\nDestination: " + destination +
                "\nPassengers: " + passengerCountStr + "\nAmount: " + totalAmount + "\nTransaction ID: " + transactionId;

        try {
            Bitmap bitmap = toBitmap(writer.encode(ticketData, BarcodeFormat.QR_CODE, 500, 500));
            qrCodeImage.setImageBitmap(bitmap);

            // Save ticket data in Firestore
            saveTicketDetailsToFirestore(source, destination, passengerCount, totalAmount, transactionId);

            //Toast.makeText(this, "QR Code Generated with ID: " + transactionId, Toast.LENGTH_SHORT).show();
        } catch (WriterException e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to generate QR Code", Toast.LENGTH_SHORT).show();
        }
    }

    private void saveTicketDetailsToFirestore(String source, String destination, int passengers, int totalAmount, String transactionId) {
        Map<String, Object> ticketData = new HashMap<>();
        ticketData.put("source", source);
        ticketData.put("destination", destination);
        ticketData.put("passengers", passengers);
        ticketData.put("amount", totalAmount);
        ticketData.put("transactionId", transactionId);
        ticketData.put("timestamp", System.currentTimeMillis());
        ticketData.put("status", "valid");
        db.collection("tickets").add(ticketData).addOnSuccessListener(documentReference ->
                Toast.makeText(this, "Ticket details saved successfully!", Toast.LENGTH_SHORT).show()
        ).addOnFailureListener(e ->
                Toast.makeText(this, "Failed to save ticket details", Toast.LENGTH_SHORT).show()
        );
    }

    private Bitmap toBitmap(com.google.zxing.common.BitMatrix bitMatrix) {
        int width = bitMatrix.getWidth();
        int height = bitMatrix.getHeight();
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565);
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                bitmap.setPixel(x, y, bitMatrix.get(x, y) ? 0xFF000000 : 0xFFFFFFFF);
            }
        }
        return bitmap;
    }

//    private void payUsingUpi() {
//        String amount = amountInput.getText().toString().trim();
//        String upiId = "";    //Provide UPI ID
//
//        Uri uri = Uri.parse("upi://pay").buildUpon()
//                .appendQueryParameter("pa", upiId)
//                .appendQueryParameter("am", amount)
//                .appendQueryParameter("cu", "INR")
//                .appendQueryParameter("tn", "Payment for ticket")
//                .build();
//
//        Intent upiPayIntent = new Intent(Intent.ACTION_VIEW);
//        upiPayIntent.setData(uri);
//
//        Intent chooser = Intent.createChooser(upiPayIntent, "Pay with");
//        if (null != chooser.resolveActivity(getPackageManager())) {
//            startActivityForResult(chooser, UPI_PAYMENT);
//        } else {
//            Toast.makeText(this, "No UPI app found. Please install one to proceed.", Toast.LENGTH_SHORT).show();
//        }
//    }
//
//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//
//        if (requestCode == UPI_PAYMENT) {
//            if ((RESULT_OK == resultCode) || (resultCode == 11)) {
//                if (data != null) {
//                    String response = data.getStringExtra("response");
//                    if (response != null && response.contains("Status=success")) {
//                        Toast.makeText(this, "Payment Successful!", Toast.LENGTH_SHORT).show();
//                        generateQRCode();
//                    } else {
//                        Toast.makeText(this, "Payment Failed or Cancelled", Toast.LENGTH_SHORT).show();
//                    }
//                } else {
//                    Toast.makeText(this, "Payment Failed or Cancelled", Toast.LENGTH_SHORT).show();
//                }
//            }
//        }
//    }

}