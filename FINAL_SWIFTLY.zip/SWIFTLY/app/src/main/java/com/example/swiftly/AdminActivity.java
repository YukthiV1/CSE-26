package com.example.swiftly;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class AdminActivity extends AppCompatActivity {
    private static final String ADMIN_ID = "MainAdmin";
    private static final String ADMIN_PASSWORD = "securepassword";

    EditText adminId, password;
    Button loginButton;
    ProgressBar progressBar;
    TextView backtodriver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        adminId = findViewById(R.id.admin_id);
        password = findViewById(R.id.admin_password);
        loginButton = findViewById(R.id.admin_login_button);
        progressBar = findViewById(R.id.login_progress_bar);
        backtodriver = findViewById(R.id.backtodriver);

        // Initially, make sure the progress bar is hidden
        progressBar.setVisibility(View.GONE);

        backtodriver.setOnClickListener(v -> {
            Intent intent = new Intent(AdminActivity.this, DriverLoginActivity.class);
            startActivity(intent);
        });

        loginButton.setOnClickListener(v -> {
            String enteredId = adminId.getText().toString().trim();
            String enteredPassword = password.getText().toString().trim();

            // Validate inputs
            if (enteredId.isEmpty()) {
                adminId.setError("Admin ID is required");
                return;
            }
            if (enteredPassword.isEmpty()) {
                password.setError("Password is required");
                return;
            }

            // Show the progress bar
            setInProgress(true);

            // Simulate a login process with a delay
            new Handler().postDelayed(() -> {
                // Hide the progress bar after the delay
                setInProgress(false);

                // Check credentials
                if (enteredId.equals(ADMIN_ID) && enteredPassword.equals(ADMIN_PASSWORD)) {
                    Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();

                    // Navigate to Admin Dashboard
                    Intent intent = new Intent(AdminActivity.this, AdminDashboardActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(this, "Invalid Admin ID or Password", Toast.LENGTH_SHORT).show();
                }
            }, 2000); // Simulated delay of 2 seconds
        });
    }

    private void setInProgress(boolean inProgress) {
        if (inProgress) {
            progressBar.setVisibility(View.VISIBLE);
            loginButton.setEnabled(false);
        } else {
            progressBar.setVisibility(View.GONE);
            loginButton.setEnabled(true);
        }
    }
}
