package com.example.swiftly.model;

public class Ticket {

    private String id;              // Ticket ID (Firestore document ID)
    private String source;          // Source station
    private String destination;     // Destination station
    private String passengerCount;  // Number of passengers
    private String amount;          // Ticket amount
    private String status;          // Status of the ticket (valid/invalid)

    // Default constructor required for Firestore
    public Ticket() {
    }

    // Constructor with parameters
    public Ticket(String id, String source, String destination, String passengerCount, String amount, String status) {
        this.id = id;
        this.source = source;
        this.destination = destination;
        this.passengerCount = passengerCount;
        this.amount = amount;
        this.status = status;
    }

    // Getters and setters for each field
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getPassengerCount() {
        return passengerCount;
    }

    public void setPassengerCount(String passengerCount) {
        this.passengerCount = passengerCount;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Ticket{" +
                "id='" + id + '\'' +
                ", source='" + source + '\'' +
                ", destination='" + destination + '\'' +
                ", passengerCount='" + passengerCount + '\'' +
                ", amount='" + amount + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}
