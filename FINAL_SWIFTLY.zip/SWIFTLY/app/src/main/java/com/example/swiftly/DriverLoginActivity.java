package com.example.swiftly;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class DriverLoginActivity extends AppCompatActivity {
    private static final String TAG = "DriverLoginActivity";

    EditText driverId, password;
    Button loginButton;
    ProgressBar progressBar;
    FirebaseFirestore firestore;
    TextView admin, backtouser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_login);

        driverId = findViewById(R.id.driver_id);
        password = findViewById(R.id.driver_password);
        loginButton = findViewById(R.id.driver_login_button);
        progressBar = findViewById(R.id.login_progress_bar); // Reference ProgressBar
        admin = findViewById(R.id.admin);
        backtouser = findViewById(R.id.backtouser);

        firestore = FirebaseFirestore.getInstance();

        // Set the progress bar to be invisible initially
        progressBar.setVisibility(View.GONE);

        backtouser.setOnClickListener(v -> {
            Intent intent = new Intent(DriverLoginActivity.this, LoginPhoneNumber.class);
            startActivity(intent);
        });

        loginButton.setOnClickListener(v -> {
            String id = driverId.getText().toString().trim();
            String pass = password.getText().toString().trim();

            if (id.isEmpty()) {
                driverId.setError("Driver ID is required");
                return;
            }
            if (pass.isEmpty()) {
                password.setError("Password is required");
                return;
            }

            // Show the ProgressBar and disable the login button
            setInProgress(true);
            verifyDriverCredentials(id, pass);
        });

        admin.setOnClickListener(v -> {
            Intent intent = new Intent(DriverLoginActivity.this, AdminActivity.class);
            startActivity(intent);
        });
    }

    private void setInProgress(boolean inProgress) {
        if (inProgress) {
            progressBar.setVisibility(View.VISIBLE);
            loginButton.setEnabled(false);
        } else {
            progressBar.setVisibility(View.GONE);
            loginButton.setEnabled(true);
        }
    }

    private void verifyDriverCredentials(String id, String pass) {
        firestore.collection("drivers").document(id)
                .get()
                .addOnCompleteListener(task -> {
                    // Hide the ProgressBar and enable the login button
                    setInProgress(false);

                    if (task.isSuccessful()) {
                        DocumentSnapshot document = task.getResult();
                        if (document.exists()) {
                            // Driver exists, check password
                            String storedPassword = document.getString("password");
                            if (pass.equals(storedPassword)) {
                                Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();

                                // Navigate to the Bus Tracker Activity
                                Intent intent = new Intent(DriverLoginActivity.this, DriverDashboardActivity.class);
                                intent.putExtra("driverName", document.getString("name")); // Pass driver's name
                                intent.putExtra("driverId", id); // Pass driver's ID
                                startActivity(intent);
                            } else {
                                Toast.makeText(this, "Invalid Password", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(this, "Driver ID not found", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Log.e(TAG, "Error fetching document", task.getException());
                        Toast.makeText(this, "An error occurred. Please try again.", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
