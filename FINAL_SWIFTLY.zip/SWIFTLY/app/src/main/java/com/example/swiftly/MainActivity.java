package com.example.swiftly;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.swiftly.model.UserModel;
import com.example.swiftly.utils.FirebaseUtil;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

public class MainActivity extends AppCompatActivity {

    TextView welcomeMessage;
    TextView adminMessage;
    Button logoutButton;
    Button bustracker;
    Button crowdman, qrtick;

    private FirebaseFirestore db;
    private Handler handler;
    private String lastAdminMessage = ""; // Store the last fetched message
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize Firestore
        db = FirebaseFirestore.getInstance();

        welcomeMessage = findViewById(R.id.welcome_message);
        adminMessage = findViewById(R.id.admin_message_input);
        logoutButton = findViewById(R.id.button_logout);
        bustracker = findViewById(R.id.button_bus_tracker);
        qrtick = findViewById(R.id.button_bus_ticket);
        crowdman = findViewById(R.id.button_crowd_management);

        // Set up button listeners
        setupButtons();

        // Initialize handler to refresh the message every hour
        handler = new Handler();
        refreshMessageEveryHour();

        // Fetch the username and display the welcome message
        fetchUsername();
    }

    private void setupButtons() {
        logoutButton.setOnClickListener(v -> logout());

        bustracker.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, bustracker.class);
            startActivity(intent);
        });

        qrtick.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, qrgenerator.class);
            startActivity(intent);
        });

        crowdman.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, crowdMange.class);
            startActivity(intent);
        });
    }

    private void logout() {
        FirebaseAuth.getInstance().signOut();
        Intent intent = new Intent(MainActivity.this, LoginPhoneNumber.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK); // Clears activity stack
        startActivity(intent);
        finish(); // Optional: finish MainActivity so that the user cannot navigate back
    }

    private void fetchUsername() {
        FirebaseUtil.currentUserDetails().get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful() && task.getResult() != null) {
                    UserModel userModel = task.getResult().toObject(UserModel.class);
                    if (userModel != null) {
                        String username = userModel.getUsername();
                        welcomeMessage.setText("Welcome, " + username + "!");
                    } else {
                        welcomeMessage.setText("Welcome!");
                        Toast.makeText(MainActivity.this, "No user data found.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(MainActivity.this, "Failed to fetch user data.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

//    private void fetchAdminMessage() {
//        db.collection("messages")
//                .orderBy("timestamp") // Order by timestamp to get the latest message
//                .limit(1)
//                .get()
//                .addOnCompleteListener(task -> {
//                    if (task.isSuccessful()) {
//                        QuerySnapshot querySnapshot = task.getResult();
//                        if (!querySnapshot.isEmpty()) {
//                            // Get the latest message
//                            String message = querySnapshot.getDocuments().get(0).getString("message");
//                            adminMessage.setText(message);
//                        } else {
//                            adminMessage.setText("No admin message available.");
//                        }
//                    } else {
//                        Toast.makeText(MainActivity.this, "Failed to fetch admin message", Toast.LENGTH_SHORT).show();
//                    }
//                });
//    }

//    private void refreshMessageEveryHour() {
//        handler.postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                fetchAdminMessage(); // Fetch the latest message
//                handler.postDelayed(this, 3600000); // Refresh every hour (3600000 ms = 1 hour)
//            }
//        }, 0); // Initial call to fetch the message immediately when activity starts
//    }
    private void fetchAdminMessage() {
        db.collection("messages")
                .orderBy("timestamp", com.google.firebase.firestore.Query.Direction.DESCENDING) // Fetch latest first
                .limit(1)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        QuerySnapshot querySnapshot = task.getResult();
                        if (!querySnapshot.isEmpty()) {
                            // Get the latest message
                            String newMessage = querySnapshot.getDocuments().get(0).getString("message");

                            // Check if the new message is different from the last fetched message
                            if (!newMessage.equals(lastAdminMessage)) {
                                lastAdminMessage = newMessage; // Update the local reference
                                adminMessage.setText(newMessage); // Update the UI
                            }
                        } else {
                            adminMessage.setText("No admin message available.");
                        }
                    } else {
                        Toast.makeText(MainActivity.this, "Failed to fetch admin message", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void refreshMessageEveryHour() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                fetchAdminMessage(); // Fetch and compare messages
                handler.postDelayed(this, 3600000); // Refresh every hour (3600000 ms = 1 hour)
            }
        }, 0); // Initial call to fetch the message immediately when activity starts
    }

}