package com.example.swiftly;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.firestore.FirebaseFirestore;
import okhttp3.*;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;

public class crowdMange extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;
    private static final String SERVER_URL = "https://a42e-34-106-211-49.ngrok-free.app/detect"; // Replace with your ngrok URL
    private ImageView imagePreview;
    private Uri imageUri;
    private Spinner depotSpinner, busSpinner;
    private Button submitButton;
    private TextView statusText;
    private ProgressBar progressBar;  // ProgressBar for upload progress

    private final HashMap<String, ArrayList<String>> busMap = new HashMap<>();
    private OkHttpClient client = new OkHttpClient();
    private static final String PREFS_NAME = "SubmissionPrefs";
    private static final int MAX_SUBMISSIONS = 4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crowd_mange);

        // Initialize views
        depotSpinner = findViewById(R.id.depotSpinner);
        busSpinner = findViewById(R.id.busSpinner);
        submitButton = findViewById(R.id.submitButton);
        imagePreview = findViewById(R.id.imagePreview);
        statusText = findViewById(R.id.statusText);
        progressBar = findViewById(R.id.progressBar);  // Initialize the ProgressBar

        // Populate bus map
        populateBusMap();

        // Populate depot spinner
        ArrayAdapter<String> depotAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, new ArrayList<>(busMap.keySet()));
        depotAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        depotSpinner.setAdapter(depotAdapter);

        depotSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, android.view.View view, int position, long id) {
                String selectedDepot = (String) parent.getItemAtPosition(position);
                updateBusSpinner(selectedDepot);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });

        // Handle image upload
        Button uploadButton = findViewById(R.id.uploadButton);
        uploadButton.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(intent, PICK_IMAGE_REQUEST);
        });

        // Handle submit
        submitButton.setOnClickListener(v -> {
            String depot = depotSpinner.getSelectedItem().toString();
            String bus = busSpinner.getSelectedItem().toString();

            if (imageUri == null) {
                Toast.makeText(this, "Please upload an image!", Toast.LENGTH_SHORT).show();
                return;
            }

            if (checkSubmissionLimit()) {
                try {
                    // Show progress bar and hide submit button during image upload
                    setInProgress(true);

                    Bitmap bitmap = BitmapFactory.decodeStream(getContentResolver().openInputStream(imageUri));
                    sendImageToServer(bitmap, depot, bus);
                } catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(this, "Failed to process image", Toast.LENGTH_SHORT).show();
                    setInProgress(false); // Hide progress bar if an error occurs
                }
            } else {
                Toast.makeText(this, "You have reached your daily submission limit.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null) {
            imageUri = data.getData();
            imagePreview.setImageURI(imageUri);
        }
    }

    private void populateBusMap() {
        busMap.put("Depot 1", new ArrayList<>(Arrays.asList("100", "101", "102")));
        busMap.put("Depot 2", new ArrayList<>(Arrays.asList("200", "201", "202")));
        busMap.put("Depot 3", new ArrayList<>(Arrays.asList("300", "301", "302")));
    }

    private void updateBusSpinner(String depot) {
        ArrayList<String> busNumbers = busMap.get(depot);
        ArrayAdapter<String> busAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, busNumbers);
        busAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        busSpinner.setAdapter(busAdapter);
    }

    private void sendImageToServer(Bitmap bitmap, String depot, String bus) {

        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream);
        byte[] byteArray = byteArrayOutputStream.toByteArray();

        MultipartBody requestBody = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("image", "image.jpg", RequestBody.create(byteArray, MediaType.parse("image/jpeg")))
                .build();

        Request request = new Request.Builder()
                .url(SERVER_URL)
                .post(requestBody)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> {
                    // Hide progress bar and show submit button on failure
                    setInProgress(false);
                    Toast.makeText(crowdMange.this, "Failed to send image", Toast.LENGTH_SHORT).show();
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (!response.isSuccessful()) {
                    runOnUiThread(() -> {
                        // Hide progress bar and show submit button on failure
                        setInProgress(false);
                        Toast.makeText(crowdMange.this, "Server error", Toast.LENGTH_SHORT).show();
                    });
                    return;
                }

                try {
                    String responseBody = response.body().string();
                    JSONObject jsonResponse = new JSONObject(responseBody);
                    int peopleCount = jsonResponse.getInt("people_count");

                    runOnUiThread(() -> {
                        // Hide progress bar and show submit button on success
                        setInProgress(false);
                        saveDataToFirestore(depot, bus, peopleCount);
                    });
                } catch (JSONException e) {
                    runOnUiThread(() -> {
                        // Hide progress bar and show submit button on JSON parsing failure
                        setInProgress(false);
                        Toast.makeText(crowdMange.this, "Error parsing server response", Toast.LENGTH_SHORT).show();
                    });
                }
            }
        });
    }

    private void saveDataToFirestore(String depot, String bus, int peopleCount) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        // Create a data object
        HashMap<String, Object> crowdData = new HashMap<>();
        crowdData.put("depot", depot);
        crowdData.put("bus", bus);
        crowdData.put("peopleCount", peopleCount);
        crowdData.put("timestamp", System.currentTimeMillis()); // Optional: add a timestamp

        // Add data to Firestore
        db.collection("crowdData")
                .add(crowdData)
                .addOnSuccessListener(documentReference -> {
                    Toast.makeText(crowdMange.this, "Report submitted successfully!", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(crowdMange.this, "Failed to save data: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private boolean checkSubmissionLimit() {
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();

        Calendar calendar = Calendar.getInstance();
        int today = calendar.get(Calendar.DAY_OF_YEAR);

        int savedDate = preferences.getInt("lastSubmissionDay", -1);
        int submissionCount = preferences.getInt("submissionCount", 0);

        if (today != savedDate) {
            submissionCount = 0;
            editor.putInt("submissionCount", 0);
            editor.putInt("lastSubmissionDay", today);
            editor.apply();
        }

        if (submissionCount >= MAX_SUBMISSIONS) {
            return false;
        } else {
            submissionCount++;
            editor.putInt("submissionCount", submissionCount);
            editor.apply();
            return true;
        }
    }

    // This method will show or hide the progress bar and button based on the inProgress status
    private void setInProgress(boolean inProgress) {
        if (inProgress) {
            progressBar.setVisibility(View.VISIBLE);  // Show the progress bar
            submitButton.setVisibility(View.GONE);    // Hide the submit button
        } else {
            progressBar.setVisibility(View.GONE);    // Hide the progress bar
            submitButton.setVisibility(View.VISIBLE); // Show the submit button again
        }
    }
}