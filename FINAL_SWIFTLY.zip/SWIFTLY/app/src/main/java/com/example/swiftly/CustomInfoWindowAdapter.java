package com.example.swiftly;

import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class CustomInfoWindowAdapter implements GoogleMap.InfoWindowAdapter {

    private final View mWindowView;

    public CustomInfoWindowAdapter(LayoutInflater inflater) {
        mWindowView = inflater.inflate(R.layout.activity_custom_info_window_adapter, null);
    }

    @Override
    public View getInfoWindow(Marker marker) {
        render(marker, mWindowView);
        return mWindowView;
    }

    @Override
    public View getInfoContents(Marker marker) {
        render(marker, mWindowView);
        return mWindowView;
    }

    private void render(Marker marker, View view) {
        String driverId = marker.getTitle();

        TextView driverIdTextView = view.findViewById(R.id.driverIdText);
        driverIdTextView.setText(driverId);
    }
}