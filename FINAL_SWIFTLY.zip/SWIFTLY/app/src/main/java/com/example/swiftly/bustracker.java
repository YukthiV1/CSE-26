package com.example.swiftly;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class bustracker extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private DatabaseReference databaseReference;
    private Handler handler;
    private Runnable locationUpdateRunnable;

    private static final int REFRESH_INTERVAL = 5000;
    private boolean isCameraMoved = false;
    private HashMap<String, Marker> driverMarkers = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bustracker);

        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION},
                1);

        databaseReference = FirebaseDatabase.getInstance().getReference("Location");

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        } else {
            Log.e("MapError", "MapFragment is null");
        }

        handler = new Handler();
        locationUpdateRunnable = new Runnable() {
            @Override
            public void run() {
                if (mMap != null) {
                    fetchLocationFromDatabase();
                }
                handler.postDelayed(this, REFRESH_INTERVAL);
            }
        };
    }

    private void fetchLocationFromDatabase() {
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (mMap == null) {
                    Log.e("MapDebug", "GoogleMap instance is null. Skipping fetchLocationFromDatabase.");
                    return;
                }

                runOnUiThread(() -> {
                    for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                        Double latitude = userSnapshot.child("latitude").getValue(Double.class);
                        Double longitude = userSnapshot.child("longitude").getValue(Double.class);

                        if (latitude != null && longitude != null) {
                            LatLng location = new LatLng(latitude, longitude);
                            String driverId = userSnapshot.getKey();

                            Marker existingMarker = driverMarkers.get(driverId);
                            if (existingMarker != null) {
                                existingMarker.setPosition(location);
                            } else {
                                Marker newMarker = mMap.addMarker(new MarkerOptions()
                                        .position(location)
                                        .title(driverId)
                                        .snippet(""));

                                driverMarkers.put(driverId, newMarker);

                                if (!isCameraMoved) {
                                    mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 12));
                                    isCameraMoved = true;
                                }
                            }
                        } else {
                            Log.e("Firebase", "Latitude or Longitude is null for driver: " + userSnapshot.getKey());
                        }
                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("Firebase", "Failed to read location: " + databaseError.getMessage());
            }
        });
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;

        mMap.setInfoWindowAdapter(new CustomInfoWindowAdapter(this.getLayoutInflater()));

        handler.post(locationUpdateRunnable);

        mMap.setOnMarkerClickListener(marker -> {
            marker.showInfoWindow();
            return true;
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(locationUpdateRunnable);
    }

    @Override
    protected void onStop() {
        super.onStop();
        handler.removeCallbacks(locationUpdateRunnable);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                handler.post(locationUpdateRunnable);
            } else {
                Log.e("Permission", "Location permission denied");
            }
        }
    }
}
