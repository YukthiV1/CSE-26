package com.example.swiftly;

public class CrowdData {
    private String depot;
    private String bus;
    private int peopleCount;

    public CrowdData() {
        // Default constructor required for Firebase
    }

    public CrowdData(String depot, String bus, int peopleCount) {
        this.depot = depot;
        this.bus = bus;
        this.peopleCount = peopleCount;
    }

    public String getDepot() {
        return depot;
    }

    public void setDepot(String depot) {
        this.depot = depot;
    }

    public String getBus() {
        return bus;
    }

    public void setBus(String bus) {
        this.bus = bus;
    }

    public int getPeopleCount() {
        return peopleCount;
    }

    public void setPeopleCount(int peopleCount) {
        this.peopleCount = peopleCount;
    }
}