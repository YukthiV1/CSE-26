package com.example.swiftly;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.common.InputImage;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ScannerActivity extends AppCompatActivity {

    private static final int CAMERA_PERMISSION_REQUEST_CODE = 1001;

    private PreviewView viewFinder;
    private TextView tvInstruction;
    private ImageButton btnBack;

    private ExecutorService cameraExecutor;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scanner);

        // Initialize views
        viewFinder = findViewById(R.id.viewFinder);
        tvInstruction = findViewById(R.id.tvInstruction);
        btnBack = findViewById(R.id.btnBack);

        // Initialize Firestore
        db = FirebaseFirestore.getInstance();

        // Handle back button
        btnBack.setOnClickListener(v -> finish());

        // Check camera permissions and start camera
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
            startCamera();
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CAMERA},
                    CAMERA_PERMISSION_REQUEST_CODE);
        }

        // Initialize camera executor
        cameraExecutor = Executors.newSingleThreadExecutor();
    }

    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> cameraProviderFuture =
                ProcessCameraProvider.getInstance(this);

        cameraProviderFuture.addListener(() -> {
            try {
                ProcessCameraProvider cameraProvider = cameraProviderFuture.get();
                bindCameraUseCases(cameraProvider);
            } catch (Exception e) {
                Toast.makeText(this, "Error starting camera: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void bindCameraUseCases(@NonNull ProcessCameraProvider cameraProvider) {
        // Camera selector for the back camera
        CameraSelector cameraSelector = new CameraSelector.Builder()
                .requireLensFacing(CameraSelector.LENS_FACING_BACK)
                .build();

        // Set up the Preview use case
        Preview preview = new Preview.Builder().build();
        preview.setSurfaceProvider(viewFinder.getSurfaceProvider());

        // Set up the ImageAnalysis use case
        ImageAnalysis imageAnalysis = new ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build();
        imageAnalysis.setAnalyzer(cameraExecutor, this::analyzeImage);

        // Bind use cases to the lifecycle
        Camera camera = cameraProvider.bindToLifecycle(
                this, cameraSelector, preview, imageAnalysis);
    }

    private void analyzeImage(@NonNull ImageProxy image) {
        @SuppressWarnings("UnsafeOptInUsageError")
        InputImage inputImage = InputImage.fromMediaImage(
                image.getImage(), image.getImageInfo().getRotationDegrees());

        BarcodeScanner scanner = BarcodeScanning.getClient();

        scanner.process(inputImage)
                .addOnSuccessListener(barcodes -> {
                    for (Barcode barcode : barcodes) {
                        String rawValue = barcode.getRawValue();
                        if (rawValue != null) {
                            handleScannedData(rawValue);
                        }
                    }
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Scan failed: " + e.getMessage(), Toast.LENGTH_SHORT).show()
                )
                .addOnCompleteListener(task -> image.close());
    }

    private void handleScannedData(String rawValue) {
        String sanitizedValue = rawValue.trim(); // Normalize the scanned value
        Log.d("ScannerActivity", "Sanitized Scanned Value: " + sanitizedValue);

        // Extract the transactionId from the scanned value
        String transactionId = extractTransactionId(sanitizedValue);
        Log.d("ScannerActivity", "Extracted Transaction ID: " + transactionId);

        // Query Firestore to get the ticket document based on transactionId
        db.collection("tickets")
                .whereEqualTo("transactionId", transactionId)  // Make sure your field name is correct
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    Log.d("Firestore", "Number of tickets found: " + queryDocumentSnapshots.size());

                    if (!queryDocumentSnapshots.isEmpty()) {
                        // Get the first document from the query
                        queryDocumentSnapshots.getDocuments().get(0).getReference()
                                .update("status", "invalid")  // Update status to invalid
                                .addOnSuccessListener(aVoid -> {
                                    // Show a valid ticket message
                                    Toast.makeText(this, "Valid ticket!", Toast.LENGTH_SHORT).show();
                                    Log.d("Firestore", "Ticket status successfully updated.");
                                })
                                .addOnFailureListener(e -> {
                                    Log.e("Firestore", "Error updating ticket status: " + e.getMessage());
                                    Toast.makeText(this, "Failed to update ticket: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                });
                    } else {
                        // If no ticket is found with the scanned transactionId
                        Log.d("Firestore", "No ticket found with transactionId: " + transactionId);
                        Toast.makeText(this, "Invalid ticket scanned.", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e -> {
                    // Handle error in the Firestore query
                    Log.e("Firestore", "Error verifying ticket: " + e.getMessage());
                    Toast.makeText(this, "Error verifying ticket: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    // This method is used to extract the transactionId from the rawValue (you can adjust as needed)
    private String extractTransactionId(String rawValue) {
        // Assuming transactionId is the last part of the string (after the last newline, for example)
        // Modify this logic as per your data structure
        String[] parts = rawValue.split("\n"); // Splitting by newline, adjust if necessary
        for (String part : parts) {
            if (part.contains("Transaction ID:")) {
                return part.replace("Transaction ID:", "").trim();  // Remove the label and return the ID
            }
        }
        return null;  // Return null if no transaction ID is found
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (cameraExecutor != null) {
            cameraExecutor.shutdown();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startCamera();
            } else {
                Toast.makeText(this, "Camera permission is required to use the scanner", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
