package com.example.swiftly;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.hbb20.CountryCodePicker;

public class LoginPhoneNumber extends AppCompatActivity {
    CountryCodePicker countryCodePicker;
    EditText phone;
    Button sendOtp;
    ProgressBar progressBar;
    TextView driverOption;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_phone_number);

        countryCodePicker = findViewById(R.id.login_ccode);
        phone = findViewById(R.id.login_phone);
        sendOtp = findViewById(R.id.login_otpsend);
        progressBar = findViewById(R.id.login_progress_bar);
        driverOption = findViewById(R.id.driver_option);

        progressBar.setVisibility(View.GONE);
        countryCodePicker.registerCarrierNumberEditText(phone);

        sendOtp.setOnClickListener((v) -> {
            if (!countryCodePicker.isValidFullNumber()) {
                phone.setError("Phone number not valid");
                return;
            }
            Intent intent = new Intent(LoginPhoneNumber.this, LoginOTP.class);
            intent.putExtra("phone", countryCodePicker.getFullNumberWithPlus());
            startActivity(intent);
        });

        driverOption.setOnClickListener((v) -> {
            // Navigate to the driver-specific page
            Intent intent = new Intent(LoginPhoneNumber.this, DriverLoginActivity.class);
            startActivity(intent);
        });
    }
}
