package com.example.swiftly;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.swiftly.model.UserModel;
import com.example.swiftly.utils.FirebaseUtil;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentSnapshot;

public class LoginUsername extends AppCompatActivity {
    EditText usernameIn;
    Button done;
    ProgressBar progressBar;
    String phoneNumber;
    UserModel userModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_username);

        usernameIn = findViewById(R.id.login_username);
        done = findViewById(R.id.login_done);
        progressBar = findViewById(R.id.login_progress_bar);

        phoneNumber = getIntent().getStringExtra("phone");
        if (phoneNumber == null) {
            Toast.makeText(this, "Phone number not provided!", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        getUsername();

        done.setOnClickListener(v -> setUsername());
    }

    void getUsername() {
        setInProgress(true);
        FirebaseUtil.currentUserDetails().get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                setInProgress(false);
                if (task.isSuccessful()) {
                    userModel = task.getResult().toObject(UserModel.class);
                    if (userModel != null) {
                        usernameIn.setText(userModel.getUsername());
                    }
                } else {
                    Toast.makeText(LoginUsername.this, "Failed to fetch user details. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    void setUsername() {
        String username = usernameIn.getText().toString().trim();
        if (username.isEmpty() || username.length() < 3) {
            usernameIn.setError("Username should be greater than 3 characters");
            return;
        }

        if (userModel != null && username.equals(userModel.getUsername())) {
            Toast.makeText(this, "No changes to save.", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(LoginUsername.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            return;
        }

        setInProgress(true);
        if (userModel != null) {
            userModel.setUsername(username);
        } else {
            userModel = new UserModel(phoneNumber, username, Timestamp.now());
        }

        FirebaseUtil.currentUserDetails().set(userModel).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                setInProgress(false);
                if (task.isSuccessful()) {
                    Intent intent = new Intent(LoginUsername.this, MainActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                } else {
                    Toast.makeText(LoginUsername.this, "Failed to save username. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    void setInProgress(boolean inProgress) {
        if (inProgress) {
            progressBar.setVisibility(View.VISIBLE);
            done.setVisibility(View.GONE);
            done.setEnabled(false);
        } else {
            progressBar.setVisibility(View.GONE);
            done.setVisibility(View.VISIBLE);
            done.setEnabled(true);
        }
    }
}
