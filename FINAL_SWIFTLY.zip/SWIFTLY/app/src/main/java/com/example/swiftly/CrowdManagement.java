package com.example.swiftly;

import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.*;

public class CrowdManagement extends AppCompatActivity {

    private Spinner depotSpinner;
    private Button fetchDataButton;
    private Button submitMessageButton;
    private EditText messageInput;
    private LinearLayout resultsLayout;
    private final HashMap<String, ArrayList<String>> busMap = new HashMap<>();
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crowd_management);

        // Initialize Firebase Firestore
        db = FirebaseFirestore.getInstance();

        // Initialize UI elements
        depotSpinner = findViewById(R.id.depotSpinner);
        fetchDataButton = findViewById(R.id.fetchDataButton);
        submitMessageButton = findViewById(R.id.submitMessageButton);
        messageInput = findViewById(R.id.messageInput);
        resultsLayout = findViewById(R.id.resultsLayout);

        // Populate bus map
        populateBusMap();

        // Populate depot spinner
        ArrayAdapter<String> depotAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, new ArrayList<>(busMap.keySet()));
        depotAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        depotSpinner.setAdapter(depotAdapter);

        // Set up fetch data button click listener
        fetchDataButton.setOnClickListener(v -> fetchBusCountsForDepot());

        // Set up submit message button click listener
        submitMessageButton.setOnClickListener(v -> sendMessageToFirestore());
    }

    private void populateBusMap() {
        busMap.put("Depot 1", new ArrayList<>(Arrays.asList("100", "101", "102")));
        busMap.put("Depot 2", new ArrayList<>(Arrays.asList("200", "201", "202")));
        busMap.put("Depot 3", new ArrayList<>(Arrays.asList("300", "301", "302")));
    }

    private void fetchBusCountsForDepot() {
        resultsLayout.removeAllViews(); // Clear previous results

        String selectedDepot = depotSpinner.getSelectedItem().toString();
        long oneHourAgo = System.currentTimeMillis() - (60 * 60 * 1000); // Calculate one hour ago

        // Query the crowdData collection for the selected depot
        db.collection("crowdData")
                .whereEqualTo("depot", selectedDepot)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Map<String, Integer> busCountMap = new HashMap<>();

                        for (QueryDocumentSnapshot document : task.getResult()) {
                            String bus = document.getString("bus");
                            int peopleCount = document.getLong("peopleCount").intValue();
                            long timestamp = document.getLong("timestamp");

                            // Skip records older than one hour
                            if (timestamp < oneHourAgo) {
                                continue;
                            }

                            // Aggregate counts for each bus
                            busCountMap.put(bus, busCountMap.getOrDefault(bus, 0) + peopleCount);
                        }

                        // Display the aggregated bus counts
                        displayDepotResults(selectedDepot, busCountMap);
                    } else {
                        Toast.makeText(this, "Failed to fetch data for depot " + selectedDepot, Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void displayDepotResults(String depot, Map<String, Integer> busCountMap) {
        // Iterate over the bus counts and create a CardView for each bus
        for (Map.Entry<String, Integer> entry : busCountMap.entrySet()) {
            String busNumber = entry.getKey();
            int count = entry.getValue();

            // Create a CardView to hold the results
            CardView cardView = new CardView(this);
            cardView.setCardElevation(10);  // Adjusted elevation for better shadow
            cardView.setRadius(12);  // Adjusted radius for smooth corners
            cardView.setUseCompatPadding(true);
            cardView.setPadding(16, 16, 16, 16);

            // Create a vertical LinearLayout for the card content
            LinearLayout cardContent = new LinearLayout(this);
            cardContent.setOrientation(LinearLayout.VERTICAL);
            cardContent.setPadding(16, 16, 16, 16);  // Padding within the LinearLayout

            // Add depot name
            addTextView(cardContent, "Depot: " + depot, true);

            // Add bus number
            addTextView(cardContent, "Bus: " + busNumber, false);

            // Add crowd count
            addTextView(cardContent, "People Count: " + count, false);

            // Add the content layout to the card
            cardView.addView(cardContent);

            // Add the card to the results layout
            resultsLayout.addView(cardView);
        }
    }

    private void addTextView(LinearLayout layout, String text, boolean isBold) {
        TextView textView = new TextView(this);
        textView.setText(text);

        // Set styling
        textView.setTextSize(16);  // Standard text size
        textView.setTextColor(getResources().getColor(R.color.black));  // Text color

        if (isBold) {
            textView.setTypeface(null, Typeface.BOLD);  // Bold for headings
            textView.setTextSize(18);  // Slightly larger size for bold text
        } else {
            textView.setTypeface(null, Typeface.NORMAL);  // Regular text for details
        }

        // Add some space between lines
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(0, 8, 0, 8);  // Add margin between text elements
        textView.setLayoutParams(params);

        layout.addView(textView);
    }

    private void sendMessageToFirestore() {
        String message = messageInput.getText().toString().trim();

        if (message.isEmpty()) {
            Toast.makeText(this, "Please type a message", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create a new message document with message, sender (admin), and timestamp
        Map<String, Object> messageData = new HashMap<>();
        messageData.put("message", message);
        messageData.put("sender", "Admin");
        messageData.put("timestamp", System.currentTimeMillis());

        // Add the message to Firestore in the "messages" collection
        db.collection("messages")
                .add(messageData)
                .addOnSuccessListener(documentReference -> {
                    Toast.makeText(this, "Message sent successfully", Toast.LENGTH_SHORT).show();
                    messageInput.setText(""); // Clear input field after sending
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed to send message", Toast.LENGTH_SHORT).show();
                });
    }
}